<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$nama = mysqli_real_escape_string($mysqli, $_POST['nama']);
	$nim = mysqli_real_escape_string($mysqli, $_POST['nim']);
	$jam_masuk = mysqli_real_escape_string($mysqli, $_POST['jam_masuk']);
	// $jam_keluar = mysqli_real_escape_string($mysqli, $_POST['jam_keluar']);
		
	// checking empty fields
	if(empty($nama) || empty($nim) || empty($jam_masuk)) {
				
		if(empty($nama)) {
			echo "<font color='red'>Nama field is empty.</font><br/>";
		}
		
		if(empty($nim)) {
			echo "<font color='red'>nim field is empty.</font><br/>";
		}
		
		if(empty($jam_masuk)) {
			echo "<font color='red'>jam_masuk field is empty.</font><br/>";
		}
		// if(empty($jam_keluar)) {
		// 	echo "<font color='red'>jam keluar field is empty.</font><br/>";
		// }
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO users(nama,nim,jam_masuk,jam_keluar) VALUES('$nama','$nim','$jam_masuk','')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>
