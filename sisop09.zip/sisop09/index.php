<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id ASC"); // using mysqli_query instead
?>

<html>
	<head>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
		<title>Homepage</title>
	</head>

	<body>
		<div class="container">
			<h2 style="text-align:center">Daftar Kunjungan Perpustakaan</h2>
			<?php echo date('l, d M Y'); ?>
			<br>
			<br>
			<a href="add.html">Tambahkan Data</a><br/><br/>

			<table class="table table-success table-striped" width='100%' border="0">

				<tr bgcolor='#CCCCCC'>
					<td>No</td>
					<td>Nama Mahasiswaa</td>
					<td>NIM</td>
					<td class="text-center">Jam Masuk</td>
					<td class="text-center">Jam Keluar</td>
					<td>Update</td>
				</tr>
				<?php 
			//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
			$no = 1;
			while($res = mysqli_fetch_array($result)) { 		
				echo "<tr>";
				echo "<td>".$no."</td>";
				echo "<td>".$res['nama']."</td>";
				echo "<td>".$res['nim']."</td>";
				echo "<td class='text-center'>".$res['jam_masuk']."</td>";	
				echo "<td class='text-center'>".$res['jam_keluar']."</td>";	
				echo "<td><a href=\"edit.php?id=$res[id]\">Edit</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
			$no++;
			}
			?>
			</table>
		</div>

	</body>
</html>
