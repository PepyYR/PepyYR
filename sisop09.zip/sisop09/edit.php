<?php
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$nama = mysqli_real_escape_string($mysqli, $_POST['nama']);
	$nim = mysqli_real_escape_string($mysqli, $_POST['nim']);
	$jam_masuk = mysqli_real_escape_string($mysqli, $_POST['jam_masuk']);	
	$jam_keluar = mysqli_real_escape_string($mysqli, $_POST['jam_keluar']);	
	
	// checking empty fields
	if(empty($nama) || empty($nim) || empty($jam_masuk) || empty($jam_keluar)) {	
			
		if(empty($nama)) {
			echo "<font color='red'>Nama field is empty.</font><br/>";
		}
		
		if(empty($nim)) {
			echo "<font color='red'>Nim field is empty.</font><br/>";
		}
		
		if(empty($jam_masuk)) {
			echo "<font color='red'>Jam Masuk field is empty.</font><br/>";
		}

		if(empty($jam_keluar)) {
			echo "<font color='red'>Jam Keluar field is empty.</font><br/>";
		}		
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users SET nama='$nama',nim='$nim',jam_masuk='$jam_masuk',jam_keluar='$jam_keluar' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$nama = $res['nama'];
	$nim = $res['nim'];
	$jam_masuk = $res['jam_masuk'];
	$jam_keluar = $res['jam_keluar'];
}
?>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>Edit Data</title>
</head>

<body>
	<div class="container">
		<h3 class="text-center">Edit Data</h3>
		<a href="index.php">Home</a>
		<br/><br/>
		<form name="form1" method="post" action="edit.php">
			<table width="80%" border="0">
				<tr> 
					<td>Nama Mahasiswa</td>
					<td width="20"></td>
					<td><input class="form-control" type="text" name="nama" value="<?php echo $nama;?>"></td>
				</tr>
				<tr> 
					<td>Nim</td>
					<td width="20"></td>
					<td><input class="form-control" type="text" name="nim" value="<?php echo $nim;?>"></td>
				</tr>
				<tr> 
					<td>Jam Masuk</td>
					<td width="20"></td>
					<td><input class="form-control" type="text" name="jam_masuk" value="<?php echo $jam_masuk;?>"></td>
				</tr>
				<tr> 
					<td>Jam Keluar</td>
					<td width="20"></td>
					<td><input class="form-control" type="text" name="jam_keluar" value="<?php echo $jam_keluar;?>"></td>
				</tr>
				<tr>
					<td><input class="form-control" type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
					<td width="20"></td>					
					<td><input class="btn btn-primary w-100" type="submit" name="update" value="Update"></td>
				</tr>
			</table>
		</form>
	</div>
	
</body>
</html>
